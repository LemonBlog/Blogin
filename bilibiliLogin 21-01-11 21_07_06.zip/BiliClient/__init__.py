
__version__ = '1.1.9'

from .asyncBiliApi import asyncBiliApi as asyncbili

__all__ = (
    'asyncbili',
)